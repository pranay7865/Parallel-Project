package com.cg.ppws.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.ppws.bean.SJAccount;
import com.cg.ppws.bean.SJTransaction;
import com.cg.ppws.dao.SJAccountRepository;
import com.cg.ppws.dao.SJTransactionRepository;

import oracle.net.aso.a;

@Service
public class SJAccountService {

	@Autowired
	SJAccountRepository repoAccount;
	@Autowired
	SJTransactionRepository repoTr;

	Optional<SJAccount> option;
	SJTransaction transaction;
	SJAccount account;

	public String addAccount(SJAccount account1) {
		account1.setDateCreated(Date.valueOf(LocalDate.now()));
		account1.setWallet(0d);
		repoAccount.save(account1);
		addTransaction(account1,account1.getBalance(),"account created");
		return "your Account Id is: "+account1.getId();
	}


	public SJAccount getAccount(SJAccount account1) {

		option =repoAccount.findById(account1.getId());
		if(option.isPresent())
			return option.get();
		return null;
	}


	public SJAccount deposit(double amount, int id) {

		account=repoAccount.findById(id).get();
		account.setBalance(account.getBalance()+amount);
		repoAccount.save(account);
		addTransaction(account,amount,"credited to account");
		return account;
	}

	public SJAccount withdraw(double amount, int id) {

		account=repoAccount.findById(id).get();
		account.setBalance(account.getBalance()-amount);
		repoAccount.save(account);

		addTransaction(account,amount,"deposited from account");
		return account;
	}


	public SJAccount bankToWallet(double amount, int id) {
		account=repoAccount.findById(id).get();
		if(account.getBalance()>=amount) {
			account.setBalance(account.getBalance()-amount);
			account.setWallet(account.getWallet()+amount);
			repoAccount.save(account);

			addTransaction(account,amount,"added in wallet");
		}
		return account;
	}


	public SJAccount walletToWallet(double amount, int id, int receiver) {

		account=repoAccount.findById(id).get();
		option=repoAccount.findById(receiver);
		SJAccount receiveAccount=option.get();
		receiveAccount.setWallet(receiveAccount.getWallet()+amount);
		account.setWallet(account.getWallet()-amount);
		repoAccount.save(account);
		repoAccount.save(receiveAccount);
		addTransaction(receiveAccount,amount,"received in wallet");

		addTransaction(account,amount,"paid from wallet");
		return account;
	}


	public boolean isAccount(int id) {
		option=repoAccount.findById(id);
		if(option.isPresent()) 
			return true;
		else
			return false;
	}


	public SJAccount walletToBank(double amount, int id) {
		account=repoAccount.findById(id).get();
		account.setWallet(account.getWallet()-amount);
		account.setBalance(account.getBalance()+amount);
		repoAccount.save(account);

		addTransaction(account,amount,"wallet to bank");
		return account;
	}
	
	public void addTransaction(SJAccount account1,Double amount,String operation) {
		transaction=new SJTransaction(account1.getId(), Date.valueOf(LocalDate.now()), account1.getBalance(), amount, account1.getWallet(), operation);
		repoTr.save(transaction);
	}
	
	public List<SJTransaction> getTransactions(int id) {
		List<SJTransaction> list = new ArrayList<SJTransaction>();
		repoTr.findAll().forEach(list::add);
		list=list.stream().filter(trans->trans.getAccountId()==id).collect(Collectors.toList());
		
		return list;
	}
}
