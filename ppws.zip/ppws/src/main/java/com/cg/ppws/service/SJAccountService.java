package com.cg.ppws.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.ppws.bean.SJAccount;
import com.cg.ppws.dao.SJAccountRepository;

@Service
public class SJAccountService {

	@Autowired
	SJAccountRepository repoAccount;
	
	Optional<SJAccount> option;
	SJAccount account;
	
	public String addAccount(SJAccount account1) {
		account=new SJAccount();
		account.setDateCreated(Date.valueOf(LocalDate.now()));
		repoAccount.save(account1);
		return "your Account Id is: "+account.getId();
	}


	public SJAccount getAccount(SJAccount account1) {
		
		option =repoAccount.findById(account1.getId());
		if(option.isPresent())
			return option.get();
		return null;
	}



	public SJAccount deposit(double amount, int id) {

		account=repoAccount.findById(id).get();
			account.setBalance(account.getBalance()+amount);
			repoAccount.save(account);
		return account;
	}
	
	public SJAccount withdraw(double amount, int id) {

		account=repoAccount.findById(id).get();
		account.setBalance(account.getBalance()-amount);
		repoAccount.save(account);
		return account;
	}


	public SJAccount bankToWallet(double amount, int id) {
		account=repoAccount.findById(id).get();
		account.setBalance(account.getBalance()-amount);
		account.setWallet(account.getWallet()+amount);
		repoAccount.save(account);
		return account;
	}
}
