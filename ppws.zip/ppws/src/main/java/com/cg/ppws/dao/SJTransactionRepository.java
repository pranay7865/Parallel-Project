package com.cg.ppws.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.ppws.bean.SJTransaction;

@Repository
public interface SJTransactionRepository extends CrudRepository<SJTransaction,Integer>{
	
	Iterable<SJTransaction> findAllByAccountId(int accountId);

}
