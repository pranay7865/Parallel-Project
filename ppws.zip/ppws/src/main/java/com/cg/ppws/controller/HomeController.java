package com.cg.ppws.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ppws.bean.SJAccount;
import com.cg.ppws.service.SJAccountService;

@Controller
public class HomeController {


	@Autowired
	SJAccountService servAccount;

	SJAccount account;

	@RequestMapping("/")
	public String check(Model model) {
		model.addAttribute("account",new SJAccount());
		return "index";
	}


	@PostMapping("login")
	public String validateLogin(@ModelAttribute("account") SJAccount account1, Model model) {
		account=servAccount.getAccount(account1);

		if(account!=null)
		{
			if(account.getPassword().equals(account1.getPassword())) {
				model.addAttribute("account",account);
				return "homepage";
			}
			else {
				model.addAttribute("message","Wrong Password");
				return "index";
			}
		}
		else{
			model.addAttribute("message","Wrong Account Number");
			return "index";
		}
	}

	@RequestMapping("homepage")
	public String showHome(Model model) {

		model.addAttribute("account",account);
		return "homepage";
	}

	@RequestMapping("signup")
	public String signUp(Model model){
		model.addAttribute("account",new SJAccount());		
		return "signuppage";
	}

	@PostMapping("newaccount")
	public String newAccount(@ModelAttribute("account") SJAccount account, Model model ) {

		model.addAttribute("message",servAccount.addAccount(account));
		return "index";

	}

	@RequestMapping("deposit")
	public String deposit(Model model)
	{

		return "deposit";
	}


	@PostMapping("depositAmount")
	public String depositAmount(@RequestParam double amount, Model model)
	{

		account=servAccount.deposit(amount,account.getId());
		model.addAttribute("account", account);
		model.addAttribute("message","Successfull");
		return "deposit";
	}

	@RequestMapping("withdraw")
	public String withdraw(Model model)
	{

		return "withdraw";
	}


	@PostMapping("withdrawAmount")
	public String withdrawAmount(@RequestParam double amount, Model model)
	{
		model.addAttribute("account", account);
		if(account.getBalance()>=amount) {
			account=servAccount.withdraw(amount,account.getId());
			model.addAttribute("account", account);

			model.addAttribute("message","Successfull");
		}
		else {
			

			model.addAttribute("message","Could not complete transaction");
		}
		return "withdraw";
	}
	@RequestMapping("addToWallet")
	public String bankToWallet(Model model)
	{

		return "bankToWallet";
	}


	@PostMapping("bankToWallet")
	public String bankToWallet(@RequestParam double amount, Model model)
	{
		model.addAttribute("account", account);
		if(account.getBalance()>=amount) {
			account=servAccount.bankToWallet(amount,account.getId());
			model.addAttribute("account", account);

			model.addAttribute("message","Successfull");
		}
		else {
			

			model.addAttribute("message","Could not complete transaction");
		}
		return "withdraw";
	}
}
