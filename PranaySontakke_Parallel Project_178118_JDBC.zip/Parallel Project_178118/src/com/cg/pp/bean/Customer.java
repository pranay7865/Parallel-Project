package com.cg.pp.bean;

import java.sql.Date;
import java.time.LocalDateTime;

public class Customer 
{
	private String customerName;
	private String customerPhone;
	private String customerAddress;
	private String customerAdhar;
	private double customerBalance;
	private int customerAccountNo;
	private Date date;
	private double wallet;
	
	public double getWallet() {
		return wallet;
	}

	public void setWallet(double wallet) {
		this.wallet = wallet;
	}

	public Customer() {
		super();	
	}

	

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerAdhar() {
		return customerAdhar;
	}

	public void setCustomerAdhar(String customerAdhar) {
		this.customerAdhar = customerAdhar;
	}

	public double getCustomerBalance() {
		return customerBalance;
	}

	public void setCustomerBalance(double customerBalance) {
		this.customerBalance = customerBalance;
	}

	

	public int getCustomerAccountNo() {
		return customerAccountNo;
	}

	public void setCustomerAccountNo(int customerAccountNo) {
		this.customerAccountNo = customerAccountNo;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Customer(String customerName, String customerPhone, String customerAddress, String customerAdhar,
			double customerBalance, int customerAccountNo, Date date, double wallet) {
		super();
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerAddress = customerAddress;
		this.customerAdhar = customerAdhar;
		this.customerBalance = customerBalance;
		this.customerAccountNo = customerAccountNo;
		this.date = date;
		this.wallet = wallet;
	}

	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerPhone=" + customerPhone + ", customerAddress="
				+ customerAddress + ", customerAdhar=" + customerAdhar + ", customerBalance=" + customerBalance
				+ ", customerAccountNo=" + customerAccountNo + ", date=" + date + ", wallet=" + wallet + "]";
	}

	 
	
	
	

}
