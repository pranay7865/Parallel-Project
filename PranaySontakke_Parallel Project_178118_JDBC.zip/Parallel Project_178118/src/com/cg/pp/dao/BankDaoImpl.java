package com.cg.pp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.History;
import com.cg.pp.bean.Wallet;

public class BankDaoImpl implements BankDao {
	Map<Integer, Customer> customers = new HashMap<Integer, Customer>();

	List<History> history = new ArrayList<History>();

	static Connection c;

	public BankDaoImpl() {

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			if (c == null) {
				c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "India123");
				System.out.println("Connected " + c);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	Map<Integer, Wallet> wallets = new HashMap<Integer, Wallet>();

	@Override
	public void createAccount(Customer customer) throws SQLException {
		/*
		 * customers.put(customer.getCustomerAccountNo(),customer); Wallet w=new
		 * Wallet();//(customer.getCustomerAccountNo(),0);
		 * w.setCustomerAccountNo(customer.getCustomerAccountNo());
		 * w.setWalletBalance(0d); wallets.put(customer.getCustomerAccountNo(), w);
		 */
		PreparedStatement ps = BankDaoImpl.c.prepareStatement("insert into Account values(?,?,?,?,?,?,?,?)");

		ps.setInt(1, customer.getCustomerAccountNo());
		ps.setString(2, customer.getCustomerName());
		ps.setString(3, customer.getCustomerAddress());
		ps.setString(4, customer.getCustomerPhone());
		ps.setString(5, customer.getCustomerAdhar());
		ps.setDouble(6, customer.getCustomerBalance());
		ps.setDate(7, customer.getDate());
		ps.setDouble(8, customer.getWallet());
		ps.executeQuery();

		History h = new History();
		h.setCustomerAccountNo(customer.getCustomerAccountNo());
		h.setCustomerBalance(customer.getCustomerBalance());
		h.setDepositDate(Date.valueOf(LocalDate.now()));
		h.setDescription("Account Created");
		history.add(h);

		PreparedStatement ps1 = BankDaoImpl.c.prepareStatement("Select accountno from account where AccountNo =?");
		ps1.setInt(1, customer.getCustomerAccountNo());
		ResultSet rs = ps1.executeQuery();
		if (rs.next())
			rs.getInt(1);

		putTransactions(customer.getCustomerAccountNo(), "created account", customer.getCustomerBalance());
	}

	@Override
	public void depositMoney(int cid, Double amount) throws SQLException {
		/*
		 * Customer c = customers.get(cid);
		 * c.setCustomerBalance(c.getCustomerBalance()+amount);
		 */

		PreparedStatement ps = BankDaoImpl.c
				.prepareStatement("update account set balance=balance+? where accountno =?");

		ps.setDouble(1, amount);
		ps.setInt(2, cid);
		ps.executeQuery();

		putTransactions(cid, "Deposited Money", amount);
		/*
		 * History h=new History(); h.setCustomerAccountNo(c.getCustomerAccountNo());
		 * h.setCustomerBalance(c.getCustomerBalance());
		 * h.setDepositDate(LocalDateTime.now()); h.setDescription("Deposited");
		 * history.add(h);
		 */
	}

	@Override
	public double showBalance(int cust) throws SQLException {
		/*
		 * Customer c = customers.get(cust); return c.getCustomerBalance();
		 */

		PreparedStatement ps = BankDaoImpl.c.prepareStatement("Select balance from Account where accountno =?");
		ps.setInt(1, cust);
		ResultSet rs = ps.executeQuery();
		if (rs.next())
			return rs.getDouble(1);
		else
			return -1;
	}

	@Override
	public double withdrawMoney(int cid, double amount) throws SQLException {

		/*
		 * Customer c = customers.get(cid);
		 * c.setCustomerBalance(c.getCustomerBalance()-amount);
		 * 
		 * History h=new History(); h.setCustomerAccountNo(c.getCustomerAccountNo());
		 * h.setCustomerBalance(c.getCustomerBalance());
		 * h.setDepositDate(LocalDateTime.now()); h.setDescription("Withdrawn");
		 * history.add(h); return c.getCustomerBalance();
		 */

		PreparedStatement ps = BankDaoImpl.c.prepareStatement("update account set balance=balance-? where accountno=?");

		ps.setDouble(1, amount);
		ps.setInt(2, cid);
		ResultSet rs = ps.executeQuery();

		ps = BankDaoImpl.c.prepareStatement("select balance from account where accountno=?");
		ps.setInt(1, cid);
		rs = ps.executeQuery();
		putTransactions(cid, "Withdraw Money", amount);
		if (rs.next())
			return rs.getDouble(1);
		else
			return 0;
	}

	@Override
	public void bankToWallet(int accountId, int amount1) throws SQLException {
		/*
		 * Customer c = customers.get(accountId); Wallet w = wallets.get(accountId);
		 * double balance=c.getCustomerBalance(); double walletBalance =
		 * w.getWalletBalance(); if(amount1<=balance)
		 * {c.setCustomerBalance(balance-amount1);
		 * w.setWalletBalance(walletBalance+amount1); History h=new History();
		 * h.setCustomerAccountNo(c.getCustomerAccountNo());
		 * h.setCustomerBalance(c.getCustomerBalance());
		 * h.setDepositDate(LocalDateTime.now()); h.setDescription("Added to wallet");
		 * history.add(h); } else { System.out.println("You don't have enough balance");
		 * }
		 */

		PreparedStatement ps = BankDaoImpl.c.prepareStatement("update account set balance=balance-? where accountno=?");

		ps.setInt(1, amount1);
		ps.setInt(2, accountId);
		ps.executeQuery();

		ps = BankDaoImpl.c.prepareStatement("update account set wallet=wallet+? where accountNo=?");

		ps.setInt(1, amount1);
		ps.setInt(2, accountId);
		ps.executeQuery();
		putTransactions(accountId, "Bank To wallet", amount1);

	}

	@Override
	public void walletToBank(int accountId, int amount1) throws SQLException {
		/*
		 * Customer c = customers.get(accountId); Wallet w = wallets.get(accountId);
		 * double balance=c.getCustomerBalance(); double walletBalance =
		 * w.getWalletBalance(); if(walletBalance>=amount1) {
		 * c.setCustomerBalance(balance+amount1);
		 * w.setWalletBalance(walletBalance-amount1); History h=new History();
		 * h.setCustomerAccountNo(c.getCustomerAccountNo());
		 * h.setCustomerBalance(c.getCustomerBalance());
		 * h.setDepositDate(LocalDateTime.now()); h.setDescription("Added to bank");
		 * history.add(h); } else { System.out.println("You don't have enough balance");
		 * }
		 */

		PreparedStatement ps = BankDaoImpl.c.prepareStatement("update account set balance=balance+? where accountno=?");

		ps.setInt(1, amount1);
		ps.setInt(2, accountId);
		ps.executeQuery();

		ps = BankDaoImpl.c.prepareStatement("update account set wallet=wallet-? where accountno=?");

		ps.setInt(1, amount1);
		ps.setInt(2, accountId);
		ps.executeQuery();

		putTransactions(accountId, "wallet To bank", amount1);
	}

	@Override
	public void walletToWallet(int accountId, int receiverId, int amount1) throws SQLException {
		/*
		 * Customer c=customers.get(accountId); Wallet w = wallets.get(accountId);
		 * Wallet w1 = wallets.get(receiverId); double wBalance = w.getWalletBalance();
		 * double w1Balance = w1.getWalletBalance(); if (wBalance>=amount1) {
		 * w.setWalletBalance(wBalance-amount1); w1.setWalletBalance(w1Balance+amount1);
		 * History h=new History(); h.setCustomerAccountNo(c.getCustomerAccountNo());
		 * h.setCustomerBalance(c.getCustomerBalance());
		 * h.setDepositDate(LocalDateTime.now());
		 * h.setDescription("wallet to wallet transfer"); history.add(h); } else {
		 * System.out.println("You don't have enough balance to transfer"); }
		 */

		PreparedStatement ps = BankDaoImpl.c.prepareStatement("update account set wallet=wallet-? where accountno=?");
		ps.setInt(1, amount1);
		ps.setInt(2, accountId);
		ps.executeQuery();

		ps = BankDaoImpl.c.prepareStatement("update account set wallet=wallet+? where accountno=?");
		ps.setInt(1, amount1);
		ps.setInt(2, receiverId);
		ps.executeQuery();
		putTransactions(accountId, "walletToWallet", amount1);

	}

	@Override
	public double showWalletBalance(int cust) throws SQLException {

		/*
		 * Wallet w = wallets.get(cust); return w.getWalletBalance();
		 */

		PreparedStatement ps = BankDaoImpl.c.prepareStatement("Select wallet from account where accountno =?");
		ps.setInt(1, cust);
		ResultSet rs = ps.executeQuery();
		if (rs.next())
			return rs.getDouble(1);
		return rs.getDouble(1);
	}

	@Override
	public List getHistory(int accountId) throws SQLException {

		/*
		 * List<History> hlist=new ArrayList<History>(); for(History h:history) {
		 * if(h.getCustomerAccountNo()==accountId) { hlist.add(h); } }
		 * 
		 * return hlist;
		 */
		List<History> listH = new ArrayList<History>();
		PreparedStatement ps = BankDaoImpl.c.prepareStatement("Select * from Transaction where accountno=?");
		ps.setInt(1, accountId);
		History h;
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			h = new History();
			h.setCustomerAccountNo(rs.getInt(1));
			h.setCustomerBalance(rs.getDouble(2));
			h.setWallet(rs.getDouble(3));
			h.setDepositDate(rs.getDate(4));
			h.setAmount(rs.getDouble(5));
			h.setDescription(rs.getString(6));
			
			listH.add(h);
		}
		return listH;

	}

	public void putTransactions(int accountId, String operation, double amount) throws SQLException {
		Customer a = new Customer();
		History h = null;
		PreparedStatement ps = BankDaoImpl.c.prepareStatement("Select * from Account where accountno=?");
		ps.setInt(1, accountId);
		ResultSet rs = ps.executeQuery();

		/*
		 * String customerName, String customerPhone, String customerAddress, String
		 * customerAdhar, double customerBalance, int customerAccountNo, Date date,
		 * double wallet
		 */
		if (rs.next()) {
			a.setCustomerAccountNo(rs.getInt(1));
			a.setCustomerName(rs.getString(2));
			a.setCustomerAddress(rs.getString(3));
			a.setCustomerPhone(rs.getString(4));
			a.setCustomerAdhar(rs.getString(5));
			a.setCustomerBalance(rs.getDouble(6));
			a.setDate(rs.getDate(7));
			a.setWallet(rs.getDouble(8));
		}

		History t = new History();
		t.setCustomerAccountNo(a.getCustomerAccountNo());
		t.setCustomerBalance(a.getCustomerBalance());
		t.setWallet(a.getWallet());
		t.setAmount(amount);
		t.setDepositDate(Date.valueOf(LocalDate.now()));
		t.setDescription(operation);

		/*
		 * (accountno number, balance double precision, wallet double precision, date1
		 * Date, amount double precision, action varchar2(30));
		 */
		ps = BankDaoImpl.c.prepareStatement("insert into transaction values(?,?,?,?,?,?)");
		ps.setInt(1, t.getCustomerAccountNo());
		ps.setDouble(2, t.getCustomerBalance());
		ps.setDouble(3, t.getWallet());
		ps.setDate(4, t.getDepositDate());
		ps.setDouble(5, amount);
		ps.setString(6, operation);
		ps.executeQuery();
	}

}
