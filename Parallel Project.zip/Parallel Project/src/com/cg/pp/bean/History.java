package com.cg.pp.bean;

import java.time.LocalDateTime;

public class History 
{
	private String customerName;
	private String customerPhone;
	private String customerAddress;
	private String customerAdhar;
	private String customerBalance;
	private String customerDeposit;
	private int customerAccountNo;
	private LocalDateTime depositDate;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerAdhar() {
		return customerAdhar;
	}
	public void setCustomerAdhar(String customerAdhar) {
		this.customerAdhar = customerAdhar;
	}
	public String getCustomerBalance() {
		return customerBalance;
	}
	public void setCustomerBalance(String customerBalance) {
		this.customerBalance = customerBalance;
	}
	public String getCustomerDeposit() {
		return customerDeposit;
	}
	public void setCustomerDeposit(String customerDeposit) {
		this.customerDeposit = customerDeposit;
	}
	public int getCustomerAccountNo() {
		return customerAccountNo;
	}
	public void setCustomerAccountNo(int customerAccountNo) {
		this.customerAccountNo = customerAccountNo;
	}
	public LocalDateTime getDepositDate() {
		return depositDate;
	}
	public void setDepositDate(LocalDateTime depositDate) {
		this.depositDate = depositDate;
	}
	
	

}
