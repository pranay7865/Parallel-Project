package com.cg.pp.service;

import com.cg.pp.bean.Customer;
import com.cg.pp.exception.BankException;

public interface BankService 
{
	
	public Customer addNewAccount(Customer customer);
	
	void validateName(String customerName) throws BankException;

	void validateAddress(String customerAddress) throws BankException;

	void validatePhone(String customerPhone) throws BankException;

	void validateDeposit(String customerDeposit) throws BankException;

	void validateAdhar(String customerAdhar) throws BankException;

}
