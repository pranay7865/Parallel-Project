package com.cg.pp.service;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.History;
import com.cg.pp.dao.BankDao;
import com.cg.pp.dao.BankDaoImpl;
import com.cg.pp.exception.BankException;

public class BankServiceImpl implements BankService
{
	BankDao dao = new BankDaoImpl();
	
	Map<Integer,Customer> customer1 = new HashMap<Integer,Customer>();
	Map<Integer,History> history1 = new HashMap<Integer,History>();
	
	@Override
	public Customer addNewAccount(Customer customer) 
	{
		
		return dao.addNewAccount(customer);
	}

	@Override
	public void validateName(String customerName) throws BankException 
	{
		String customerNameRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(customerNameRegEx, customerName))
		{
			throw new BankException("Enter alphabets only.");
		}		
	}

	@Override
	public void validateAddress(String customerAddress) throws BankException 
	{		
		String customerAddressRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(customerAddressRegEx, customerAddress))
		{
			throw new BankException("Enter alphabets only.");
		}	
	}

	@Override
	public void validatePhone(String customerPhone) throws BankException 
	{
		String customerPhoneRegEx = "[7-9]{1}[0-9]{9}";
		if(!Pattern.matches(customerPhoneRegEx, customerPhone))
		{
			throw new BankException("Enter digits only.");
		}	
	}

	@Override
	public void validateDeposit(String customerDeposit) throws BankException 
	{
		String customerDepositRegEx = "[0-9]+";
		if(!Pattern.matches(customerDepositRegEx, customerDeposit))
		{
			throw new BankException("Enter digits only.");
		}	
	}

	@Override
	public void validateAdhar(String customerAdhar) throws BankException 
	{
		String customerAdharRegEx = "[0-9]{12}";
		if(!Pattern.matches(customerAdharRegEx, customerAdhar))
		{
			throw new BankException("Enter digits only.");
		}	
		
	}

	
	
	
	

}
