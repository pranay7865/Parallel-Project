package com.cg.pp.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.pp.bean.Customer;
import com.cg.pp.exception.BankException;
import com.cg.pp.service.BankService;
import com.cg.pp.service.BankServiceImpl;

public class Client 
{

	public static void main(String[] args) 
	{

		BankService service = new BankServiceImpl();
		Scanner scanner = null;
		Customer customer = new Customer();

		String continueChoice = "";
		boolean continueChoiceFlag = false;

		do
		{
			System.out.println("******* Welcome to Axis Bank E-Wallet *******");
			System.out.println("1. Create an Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");

			int choice = 0;
			boolean choiceFlag =false;

			do
			{
				scanner = new Scanner(System.in);
				System.out.println("Enter your Choice : ");

				try 
				{
					choice = scanner.nextInt();
					choiceFlag = true;

					switch(choice)
					{

					case 1:

						String customerName = "";
						boolean customerNameFlag = false;						
						do
						{
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Name : ");
							try {
								customerName=scanner.nextLine();
								service.validateName(customerName);
								customer.setCustomerName(customerName);
								customerNameFlag=true;
							} catch (BankException e) {
								customerNameFlag = false;
								System.err.println(e.getMessage());
							}
						}while(!customerNameFlag);

						String customerAddress = "";
						boolean customerAddressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Address : ");
							try {
								customerAddress=scanner.nextLine();
								service.validateAddress(customerAddress);
								customer.setCustomerAddress(customerAddress);
								customerAddressFlag=true;
							} catch (BankException e) {
								customerAddressFlag = false;
								System.err.println(e.getMessage());
							}
						}while(!customerAddressFlag);

						String customerPhone = "";
						boolean customerPhoneFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Phone Number : ");
							try {
								customerPhone = scanner.nextLine();
								service.validatePhone(customerPhone);
								customer.setCustomerPhone(customerPhone);
								customerPhoneFlag=true;
							} catch (BankException e) {
								customerPhoneFlag = false;
								System.err.println(e.getMessage());
							}
						}while(!customerPhoneFlag);
						
						String customerDeposit = "";
						boolean customerDepositFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter the Amount you want to Deposit : ");
							try {
								customerDeposit = scanner.nextLine();
								service.validateDeposit(customerDeposit);
								customer.setCustomerDeposit(customerDeposit);
								customerDepositFlag=true;
							} catch (BankException e) {
								customerDepositFlag = false;
								System.err.println(e.getMessage());
							}
						}while(!customerDepositFlag);
						
						String customerAdhar = "";
						boolean customerAdharFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Adhar Card Number : ");
							try {
								customerAdhar = scanner.nextLine();
								service.validateAdhar(customerAdhar);
								customer.setCustomerAdhar(customerAdhar);
								customerAdharFlag=true;
							} catch (BankException e) {
								customerAdharFlag = false;
								System.err.println(e.getMessage());
							}
						}while(!customerAdharFlag);
						
						
						
						int customerAccountNo = (int)(Math.random()*1000000000);
						customer.setCustomerAccountNo(customerAccountNo);
						customer.setCustomerAccountNo(customerAccountNo);
						System.out.println("Your Account Number is "+customerAccountNo);						
						
						break;

					case 2:
					
						
						customer=service.addNewAccount(customer);
						System.out.println(customer);
						break;
					
					case 3:


						break;

					case 4:


						break;

					case 5:


						break;

					case 6:


						break;

					case 7:

						System.out.println("Thank You for using Wallet.");
								System.exit(0);

					default :

						choiceFlag = false;
						System.err.println("Input should be 1, 2, 3, 4, 5 or 6");
						break;

					}

				} catch (InputMismatchException e) 
				{
					choiceFlag = false;
					System.err.println("Please enter digits only.");
				}

			}while(!choiceFlag);
			scanner=new Scanner(System.in);
			System.out.println("Do you want to continue [Yes/No]");
			continueChoice=scanner.next();

		}while(continueChoice.equalsIgnoreCase("Yes"));
		scanner.close();
	}

}
