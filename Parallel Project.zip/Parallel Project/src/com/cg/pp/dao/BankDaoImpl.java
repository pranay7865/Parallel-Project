package com.cg.pp.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.History;

public class BankDaoImpl implements BankDao
{
	Map<Integer,Customer> customer = new HashMap<Integer,Customer>();
	
	Map<Integer,History> history = new HashMap<Integer,History>();

	@Override
	public Customer addNewAccount(Customer customer) 
	{
		((Map<Integer,Customer>) customer).put(customer.getCustomerAccountNo(),customer);		
		
	}
	
	
}
