package com.cg.pp.dao;

import com.cg.pp.bean.Customer;

public interface BankDao 
{

	public Customer addNewAccount(Customer customer);

}
