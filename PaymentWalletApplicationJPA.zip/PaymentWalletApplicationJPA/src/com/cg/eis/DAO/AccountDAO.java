package com.cg.eis.DAO;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.eis.bean.AccountJPA;
import com.cg.eis.bean.TransactionJPA;

public class AccountDAO implements DAO {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("PaymentWalletApplicationJPA");
	EntityManager em=emf.createEntityManager();
	/**
	 * To Create New Account In Database
	 * 
	 * TRANSACTIONID, AMOUNT, BALANCE, CUSTID, DATE, OPERATION, WALLETBALANCE
	 * transactionId=2251, balance=1200.0, walletBalance=0.0, amount=0.0, custId=2668, operation=Account Created, date=2019-05-18])
	 */
	public String create(AccountJPA a) throws SQLException {
	
		em.getTransaction().begin();
		em.persist(a);
		em.getTransaction().commit();
		
		//updateTransaction(a.getAcId(), a.getBalance(), "AccountCreated");
			return a.getAcId();
	}

	
	/**
	 * To Show Balance from given account number
	 */
	
	/*public Account(String acId, double balance, String name, String contact, String password, double wallet)*/
	
	@Override
	public double showAccountBalance(String acId) throws SQLException {

		AccountJPA a=em.find(AccountJPA.class, acId);
		return a.getBalance();
	}


	/**
	 * To Show Wallet Balance from given account number
	 */
	
	@Override
	public double showWalletBalance(String acId) throws SQLException {
		
		AccountJPA a=em.find(AccountJPA.class, acId);
		return a.getWallet();
	}

	/**
	 * To display all accounts in a List
	 */
	
	public List<AccountJPA> show() throws SQLException {


		Query q=em.createQuery("select a from AccountJPA a");
		
		List<AccountJPA> allAccounts=q.getResultList();
		
		return allAccounts;
	}

	/**
	 * To add Money in bank account
	 */
	@Override
	public void depositToAccount(String acId, double amount) throws SQLException {
		
		em.getTransaction().begin();
		AccountJPA a=em.find(AccountJPA.class, acId);
		a.setBalance(a.getBalance()+amount);
		em.persist(a);
		em.getTransaction().commit();
		updateTransaction(acId,amount,"Deposited");
		
	}

	/**
	 * To pay money from wallet
	 * @throws SQLException 
	 */
	@Override
	public double walletToWallet(String acId,String receiverAcId, double amount) throws SQLException {

		em.getTransaction().begin();
		AccountJPA a1=em.find(AccountJPA.class, acId);
		AccountJPA a2=em.find(AccountJPA.class, receiverAcId);
		
		a1.setWallet(a1.getWallet()-amount);
		a2.setWallet(a2.getWallet()+amount);
		
		em.persist(a1);
		em.persist(a2);
		updateTransaction(acId,amount,"Paid from wallet");
		updateTransaction(receiverAcId,amount,"Received in wallet");

		em.getTransaction().commit();
		
		return showWalletBalance(acId);
	}

	/**
	 * To add Money in wallet from bank account
	 */
	@Override
	public void bankToWallet(String acId, double amount) throws SQLException {
	
		em.getTransaction().begin();
		AccountJPA a=em.find(AccountJPA.class, acId);
		a.setBalance(a.getBalance()-amount);
		a.setWallet(a.getWallet()+amount);
		em.persist(a);
		em.getTransaction().commit();
	
		updateTransaction(acId,amount,"Added to wallet");
	}

	/** 
	 * To transfer wallet money back to account
	 */
	@Override
	public void walletToBank(String acId, double amount) throws SQLException {
		
		em.getTransaction().begin();
		AccountJPA a=em.find(AccountJPA.class, acId);
		a.setBalance(a.getBalance()+amount);
		a.setWallet(a.getWallet()-amount);
		em.persist(a);
		em.getTransaction().commit();
	
		
		updateTransaction(acId,amount,"Wallet to bank");
		
	}

	/**
	 * To get perticular account info
	 *  
	 */
	@Override
	public AccountJPA getAccount(String acId) throws SQLException {
		
		AccountJPA a=em.find(AccountJPA.class,acId);
		return a;
	}
	
	
	@Override
	public boolean isAccount(String acId) throws SQLException {
		boolean isAccount=false;
		AccountJPA a=em.find(AccountJPA.class,acId);
		if(a!=null) {
			isAccount=true;
		}
		return isAccount;
	}
	
//	String custId, double balance, double walletBalance, Date date, String operation, double amount
	@Override
	public List<TransactionJPA> getTransactions(String acId) throws SQLException {
		
		Query q1=em.createQuery("Select t from TransactionJPA t where custId=?");
		q1.setParameter(1, acId);
		List<TransactionJPA> listT=q1.getResultList();
		
		
	
		return listT;
	}


	@Override
	public boolean logIn(String acId, String password) throws SQLException {
		boolean login=false;
		
		AccountJPA a=em.find(AccountJPA.class, acId);
		if(a!=null)
			login=true;
		
		return login;
	}


	public void wrapup() throws SQLException {
		em.close();
		emf.close();
	}


	@Override
	public void updateTransaction(String acId, double amount, String operation) throws SQLException {
		em.getTransaction().begin();
		AccountJPA a=em.find(AccountJPA.class,acId);
		
		TransactionJPA t=new TransactionJPA(a.getBalance(),a.getWallet(),acId,Date.valueOf(LocalDate.now()),operation,amount);
		
		em.persist(t);
		em.getTransaction().commit();
	
	
	}

}


