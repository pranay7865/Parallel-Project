package com.cg.eis.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AccountJPA {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String acId;
	private double balance;
	private String name;
	private String contact;
	private String password;
	private double wallet;
	private Date dateCreated;
	
/*	
	public AccountJPA(String acId, double balance, String name, String contact, String password, double wallet) {
		super();
		this.acId = acId;
		this.balance = balance;
		this.name = name;
		this.contact = contact;
		this.password = password;
		this.wallet = wallet;
	}
*/
	
	public AccountJPA() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AccountJPA(String acId, String name, String contact, String password,  double balance, double wallet, Date dateCreated) {
		super();
		this.acId = acId;
		this.balance = balance;
		this.name = name;
		this.contact = contact;
		this.password = password;
		this.wallet = wallet;
		this.setDateCreated(dateCreated);
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAcId() {
		return acId;
	}
	
	public void setAcId(String acId) {
		this.acId = acId;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getContact() {
		return contact;
	}
	
	public void setContact(String contact) {
		this.contact = contact;
	}
	
/*	@Override
	public String toString() {
		return "Account [acId=" + acId + ", balance=" + balance + ", name=" + name + ", contact=" + contact
				+ ", password=" + password + ", wallet=" + wallet + "]";
	}*/
	
	

	public double getWallet() {
		return wallet;
	}

	@Override
	public String toString() {
		return "AccountJPA [acId=" + acId + ", balance=" + balance + ", name=" + name + ", contact=" + contact
				+ ", password=" + password + ", wallet=" + wallet + ", dateCreated=" + dateCreated + "]";
	}


	public void setWallet(double wallet) {
		this.wallet = wallet;
	}


	public Date getDateCreated() {
		return dateCreated;
	}


	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	

	
	
}
