package com.cg.pp.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.cg.pp.bean.Customer;
import com.cg.pp.exception.BankException;

public interface BankService 
{
	
	
	void validateName(String customerName) throws BankException;

	void validateAddress(String customerAddress) throws BankException;

	void validatePhone(String customerPhone) throws BankException;


	void validateAdhar(String customerAdhar) throws BankException;

	void createAccount(Customer customer) throws SQLException ;

	void validateAmount(int amount) throws BankException;

	void depositMoney(int cid, Double  amount) throws SQLException;

	double showBalance(int cust) throws SQLException;

	double withdrawMoney(int cid, double amount) throws SQLException;

	void bankToWallet(int accountId, int amount1) throws SQLException;

	void walletToBank(int accountId, int amount1) throws SQLException;

	void walletToWallet(int accountId, int receiverId, int amount1) throws SQLException;

	double showWalletBalance(int cust) throws SQLException;

	List getHistory(int accountIds) throws SQLException;

}
