package com.cg.pp.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.cg.pp.bean.Customer;

public interface BankDao 
{
	
	void createAccount(Customer customer) throws SQLException;

	void depositMoney(int cid, Double amount) throws SQLException;

	double showBalance(int cust) throws SQLException;

	double withdrawMoney(int cid, double amount) throws SQLException;

	void bankToWallet(int accountId, int amount1) throws SQLException;

	void walletToBank(int accountId, int amount1) throws SQLException;

	void walletToWallet(int accountId, int receiverId, int amount1) throws SQLException;

	double showWalletBalance(int cust) throws SQLException;

	List getHistory(int accountId) throws SQLException;

	
}
