package com.cg.pp.ui;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.History;
import com.cg.pp.exception.BankException;
import com.cg.pp.service.BankService;
import com.cg.pp.service.BankServiceImpl;

public class Client {

	public static void main(String[] args) throws SQLException {

		BankService service = new BankServiceImpl();
		Scanner scanner = null;
		Customer customer = null;

		String continueChoice = "";
		boolean continueChoiceFlag = false;

		
		do {
			System.out.println("******* Welcome to Axis Bank E-Wallet *******");
			System.out.println("1. Create an Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your Choice : ");

				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1:
					customer=	new Customer();
						String customerName = "";
						boolean customerNameFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Name : ");
							try {
								customerName = scanner.nextLine();
								service.validateName(customerName);
								customer.setCustomerName(customerName);
								customerNameFlag = true;
							} catch (BankException e) {
								customerNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!customerNameFlag);

						String customerAddress = "";
						boolean customerAddressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Address : ");
							try {
								customerAddress = scanner.nextLine();
								service.validateAddress(customerAddress);
								customer.setCustomerAddress(customerAddress);
								customerAddressFlag = true;
							} catch (BankException e) {
								customerAddressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!customerAddressFlag);

						String customerPhone = "";
						boolean customerPhoneFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Phone Number : ");
							try {
								customerPhone = scanner.nextLine();
								service.validatePhone(customerPhone);
								customer.setCustomerPhone(customerPhone);
								customerPhoneFlag = true;
							} catch (BankException e) {
								customerPhoneFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!customerPhoneFlag);

						String customerAdhar = "";
						boolean customerAdharFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Adhar Card Number : ");
							try {
								customerAdhar = scanner.nextLine();
								service.validateAdhar(customerAdhar);
								customer.setCustomerAdhar(customerAdhar);
								customerAdharFlag = true;
							} catch (BankException e) {
								customerAdharFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!customerAdharFlag);

						int customerAccountNo = (int) (Math.random() * 1000000);
						//customer.setCustomerAccountNo(customerAccountNo);
						//customer.setCustomerAccountNo(customerAccountNo);
						System.out.println("Your Account Number is " + customerAccountNo);
						customer.setDate1(Date.valueOf(LocalDate.now()));
						service.createAccount(customer);

						break;

					case 2:

						System.out.println("Enter customer account id : ");
						int cust = scanner.nextInt();
						double balance = service.showBalance(cust);
						System.out.println("Your Balance is " + balance);
						double walletBalance = service.showWalletBalance(cust);
						System.out.println("Your Wallet  Balance is " + walletBalance);
						break;

					case 3:

						int amount = 0;
						boolean amountFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter deposit amount : ");
							try {
								amount = scanner.nextInt();
								service.validateAmount(amount);
								amountFlag = true;
							} catch (BankException e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!amountFlag);

						System.out.println("Enter account id :");
						int cid = scanner.nextInt();

						service.depositMoney(cid, (double) amount);

						break;

					case 4:

						 amount = 0;
						 amountFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter withdraw amount : ");
							try {
								amount = scanner.nextInt();
								service.validateAmount(amount);
								amountFlag = true;
							} catch (BankException e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!amountFlag);

						System.out.println("Enter account id :");
						 cid = scanner.nextInt();

						service.withdrawMoney(cid, (double) amount);
						break;

					case 5:

						System.out.println("1. Bank to Wallet\n2. Wallet to Bank\n3. Wallet to Wallet");
						int accountId=0;
						int amount1=0;
						int choice1 = scanner.nextInt();
						switch (choice1) {
						case 1:
							
							System.out.println("Enter your account number : ");
							accountId = scanner.nextInt();
							System.out.println("Enter amount :");
							amount1=scanner.nextInt();
							service.bankToWallet(accountId,amount1);
							break;

						case 2:
							
							System.out.println("Enter your account number : ");
							accountId = scanner.nextInt();
							System.out.println("Enter amount : ");
							amount1=scanner.nextInt();
							service.walletToBank(accountId,amount1);
							break;
							
						case 3:
							
							System.out.println("Enter your account no :");
							accountId=scanner.nextInt();
							System.out.println("Enter receiver's account no :");
							int receiverId=scanner.nextInt();
							System.out.println("Enter the amount you want to want :");
							amount1=scanner.nextInt();
							service.walletToWallet(accountId,receiverId,amount1);
							break;
							
						default:
							System.out.println("Invalid Choice");
							break;
						}
						break;

					case 6:
						System.out.println("Enter your account no :");
						accountId=scanner.nextInt();
						List list=service.getHistory(accountId);
						for(Object h:list) {
							System.out.println(h);
						}
						break;

					case 7:

						System.out.println("Thank You for using Axis Bank E-Wallet.");
						System.exit(0);

					default:

						choiceFlag = false;
						System.err.println("Input should be 1, 2, 3, 4, 5 or 6");
						break;

					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("Please enter digits only.");
				}

			} while (!choiceFlag);
			scanner = new Scanner(System.in);
			System.out.println("Do you want to continue [Yes/No]");
			continueChoice = scanner.next();

		} while (continueChoice.equalsIgnoreCase("Yes"));
		scanner.close();
	}

}
