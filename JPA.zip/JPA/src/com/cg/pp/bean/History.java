package com.cg.pp.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class History 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String historyId;
	private double customerBalance;
	private int customerAccountNo;
	private Date depositDate;
	private String description;
	private double amount;
	private double wallet;
	


	public History(double customerBalance, int customerAccountNo, Date depositDate, String description,
			double amount, double wallet) {
		super();
		this.customerBalance = customerBalance;
		this.customerAccountNo = customerAccountNo;
		this.depositDate = depositDate;
		this.description = description;
		this.amount = amount;
		this.setWallet(wallet);
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getCustomerBalance() {
		return customerBalance;
	}
	public void setCustomerBalance(double customerBalance) {
		this.customerBalance = customerBalance;
	}
	
	public int getCustomerAccountNo() {
		return customerAccountNo;
	}
	public void setCustomerAccountNo(int customerAccountNo) {
		this.customerAccountNo = customerAccountNo;
	}
	public Date getDepositDate() {
		return depositDate;
	}
	public void setDepositDate(Date depositDate) {
		this.depositDate = depositDate;
	}
	@Override
	public String toString() {
		return "History [customerBalance=" + customerBalance + ", customerAccountNo=" + customerAccountNo
				+ ", depositDate=" + depositDate + ", description=" + description + ", amount=" + amount + ", wallet="
				+ wallet + "]";
	}
	public History() {
		super();
		
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getWallet() {
		return wallet;
	}
	public void setWallet(double wallet) {
		this.wallet = wallet;
	}

	

}
