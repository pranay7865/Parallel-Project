package com.cg.pp.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ABC")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerAccountNo;
	private String customerName;
	private String customerPhone;
	private double customerBalance;
	private String customerAddress;
	private String customerAdhar;
	private Date date1;
	private double wallet;
	
	public double getWallet() {
		return wallet;
	}

	public void setWallet(double wallet) {
		this.wallet = wallet;
	}

	public Customer() {
		super();	
	}

	/*CUSTOMERACCOUNTNO NUMBER(10) NOT NULL, CUSTOMERADDRESS VARCHAR2(255) NULL, CUSTOMERADHAR VARCHAR2(255) NULL, CUSTOMERBALANCE NUMBER(19,4) NULL, CUSTOMERNAME VARCHAR2(255) NULL, CUSTOMERPHONE VARCHAR2(255) NULL, DATE DATE NULL, WALLET NUMBER(19,4) NULL, PRIMARY KEY (CUSTOMERACCOUNTNO))*/

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerAdhar() {
		return customerAdhar;
	}

	public void setCustomerAdhar(String customerAdhar) {
		this.customerAdhar = customerAdhar;
	}

	public double getCustomerBalance() {
		return customerBalance;
	}

	public void setCustomerBalance(double customerBalance) {
		this.customerBalance = customerBalance;
	}

	

	public int getCustomerAccountNo() {
		return customerAccountNo;
	}

	public void setCustomerAccountNo(int customerAccountNo) {
		this.customerAccountNo = customerAccountNo;
	}

	public Customer(int customerAccountNo, String customerName, String customerPhone, String customerAddress,
			String customerAdhar, double customerBalance, Date date1, double wallet) {
		super();
		this.customerAccountNo = customerAccountNo;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerAddress = customerAddress;
		this.customerAdhar = customerAdhar;
		this.customerBalance = customerBalance;
		this.date1 = date1;
		this.wallet = wallet;
	}

	@Override
	public String toString() {
		return "Customer [customerAccountNo=" + customerAccountNo + ", customerName=" + customerName
				+ ", customerPhone=" + customerPhone + ", customerAddress=" + customerAddress + ", customerAdhar="
				+ customerAdhar + ", customerBalance=" + customerBalance + ", date1=" + date1 + ", wallet=" + wallet
				+ "]";
	}

	public Date getDate1() {
		return date1;
	}

	public void setDate1(Date date1) {
		this.date1 = date1;
	}


}
