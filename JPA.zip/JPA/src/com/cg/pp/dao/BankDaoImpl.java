package com.cg.pp.dao;


import java.sql.SQLException;


import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.History;


public class BankDaoImpl implements BankDao {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
	EntityManager em = emf.createEntityManager();

	@Override
	public void createAccount(Customer customer) throws SQLException {

		em.getTransaction().begin();
		em.persist(customer);
		/*History h = new History(customer.getCustomerBalance(), customer.getCustomerAccountNo(), customer.getDate(),
				"Account created", 0, customer.getWallet());*/
		
		em.getTransaction().commit();
		System.out.println(customer.getCustomerAccountNo());
	}

	@Override
	public void depositMoney(int cid, Double amount) throws SQLException {

		em.getTransaction().begin();
		Customer d = em.find(Customer.class, cid);
		d.setCustomerBalance(d.getCustomerBalance() + amount);
		em.persist(d);
		em.getTransaction().commit();
	}

	@Override
	public double showBalance(int cust) throws SQLException {
		
		Customer q = em.find(Customer.class, cust);
		return q.getCustomerBalance();

	}

	@Override
	public double withdrawMoney(int cid, double amount) throws SQLException {

		em.getTransaction().begin();
		Customer d = em.find(Customer.class, cid);
		d.setCustomerBalance(d.getCustomerBalance() - amount);
		em.persist(d);
		em.getTransaction().commit();
		return d.getCustomerBalance();
	}

	@Override
	public void bankToWallet(int accountId, int amount1) throws SQLException {
		em.getTransaction().begin();
		Customer c = em.find(Customer.class, accountId);
		c.setCustomerBalance(c.getCustomerBalance()- amount1);
		c.setWallet(c.getWallet()+amount1);
		em.persist(c);
		em.getTransaction().commit();
	}

	@Override
	public void walletToBank(int accountId, int amount1) throws SQLException {
		em.getTransaction().begin();
		Customer c = em.find(Customer.class, accountId);
		c.setWallet(c.getWallet()- amount1);
		c.setCustomerBalance(c.getCustomerBalance()+ amount1);
		em.persist(c);
		em.getTransaction().commit();
	}

	@Override
	public void walletToWallet(int accountId, int receiverId, int amount1) throws SQLException {
		em.getTransaction().begin();
		Customer c = em.find(Customer.class, accountId);
		Customer c1 = em.find(Customer.class, receiverId);
		c.setWallet(c.getWallet() - amount1);
		c1.setWallet(c1.getWallet() + amount1);
		em.persist(c);
		em.getTransaction().commit();
	}

	@Override
	public double showWalletBalance(int cust) throws SQLException 
	{
		Customer c = em.find(Customer.class, cust);
		c.setWallet(c.getWallet());
		em.getTransaction().commit();
		return c.getWallet();
	}

	@Override
	public List getHistory(int accountId) throws SQLException 
	{
		Query q = em.createQuery("Select h from History h where accountId =?");
		q.setParameter(1, accountId);
		List list=q.getResultList();
		return list;
	}

	public void putTransactions(int accountId, String operation, double amount) throws SQLException 
	{
		
		em.getTransaction().begin();
		Customer c = em.find(Customer.class, accountId);
		History h = new History();
		
		h.setCustomerBalance(c.getCustomerBalance());
		h.setWallet(c.getWallet());
		h.setDepositDate(c.getDate1());
		h.setAmount(amount);
		h.setDescription(operation);
		em.persist(c);
		em.getTransaction().commit();
	}

}
