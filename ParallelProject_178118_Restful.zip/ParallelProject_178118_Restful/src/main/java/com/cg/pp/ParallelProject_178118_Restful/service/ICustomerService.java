package com.cg.pp.ParallelProject_178118_Restful.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.cg.pp.ParallelProject_178118_Restful.entity.Customer;

@Service
public interface ICustomerService {

	public Customer createAccount(Customer customer);
	public double showBalance(String Mobile_no);
	public boolean fundTransfer (String sourceMobileNo,String targetMobileNo,BigDecimal amount);
	public boolean depositAmount(String Mobile_no,BigDecimal amount);
	public boolean withdrawAmount(String Mobile_no,BigDecimal amount);
	public String validateNum(String Mobile_no);
}
