package com.cg.pp.ParallelProject_178118_Restful;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pp.ParallelProject_178118_Restful.service.CustomerService;


@RestController
@SpringBootApplication
public class ParallelProject178118RestfulApplication implements ErrorController, CommandLineRunner{

	/*@Autowired
	private CustomerService service;*/

	private static final String PATH = "/error";
	
	public static void main(String[] args) {
		SpringApplication.run(ParallelProject178118RestfulApplication.class, args);
	}

	@Override
	public String getErrorPath() {
		return PATH;
	}

	@GetMapping(value = PATH)
	public String error() {
		return "Please Enter A Valid End-Point";
	}
	
	@Override
	public void run(String... args) throws Exception {
		
		
	}

}
