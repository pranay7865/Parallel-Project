package com.cg.pp.service;

import java.util.List;
import java.util.Map;

import com.cg.pp.bean.Customer;
import com.cg.pp.exception.BankException;

public interface BankService 
{
	
	
	void validateName(String customerName) throws BankException;

	void validateAddress(String customerAddress) throws BankException;

	void validatePhone(String customerPhone) throws BankException;


	void validateAdhar(String customerAdhar) throws BankException;

	void createAccount(Customer customer) ;

	void validateAmount(int amount) throws BankException;

	void depositMoney(int cid, Double  amount);

	double showBalance(int cust);

	double withdrawMoney(int cid, double amount);

	void bankToWallet(int accountId, int amount1);

	void walletToBank(int accountId, int amount1);

	void walletToWallet(int accountId, int receiverId, int amount1);

	double showWalletBalance(int cust);

	List getHistory(int accountIds);

}
