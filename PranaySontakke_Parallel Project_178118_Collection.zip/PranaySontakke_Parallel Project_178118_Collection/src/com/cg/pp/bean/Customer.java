package com.cg.pp.bean;

import java.time.LocalDateTime;

public class Customer 
{
	private String customerName;
	private String customerPhone;
	private String customerAddress;
	private String customerAdhar;
	private double customerBalance;
	
	private int customerAccountNo;
	private LocalDateTime date;
	
	public Customer() {
		super();	
	}

	public Customer(String customerName, String customerPhone, String customerAddress, String customerAdhar,
			double customerBalance,  int customerAccountNo, LocalDateTime date) {
		super();
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerAddress = customerAddress;
		this.customerAdhar = customerAdhar;
		this.customerBalance = customerBalance;
		
		this.customerAccountNo = customerAccountNo;
		this.date = date;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerAdhar() {
		return customerAdhar;
	}

	public void setCustomerAdhar(String customerAdhar) {
		this.customerAdhar = customerAdhar;
	}

	public double getCustomerBalance() {
		return customerBalance;
	}

	public void setCustomerBalance(double customerBalance) {
		this.customerBalance = customerBalance;
	}

	

	public int getCustomerAccountNo() {
		return customerAccountNo;
	}

	public void setCustomerAccountNo(int customerAccountNo) {
		this.customerAccountNo = customerAccountNo;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerPhone=" + customerPhone + ", customerAddress="
				+ customerAddress + ", customerAdhar=" + customerAdhar + ", customerBalance=" + customerBalance
				+ ", customerAccountNo=" + customerAccountNo + ", date=" + date
				+ "]";
	}

	
	
	

}
