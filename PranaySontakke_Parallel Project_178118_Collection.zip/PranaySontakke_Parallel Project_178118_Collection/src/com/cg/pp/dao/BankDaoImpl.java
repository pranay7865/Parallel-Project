package com.cg.pp.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.History;
import com.cg.pp.bean.Wallet;

public class BankDaoImpl implements BankDao
{
	Map<Integer,Customer> customers = new HashMap<Integer,Customer>();
	
	List<History> history = new ArrayList<History>();
	
	Map<Integer,Wallet> wallets = new HashMap<Integer,Wallet>();

	@Override
	public void createAccount(Customer customer) 
	{
		customers.put(customer.getCustomerAccountNo(),customer);
		Wallet w=new Wallet();//(customer.getCustomerAccountNo(),0);
		w.setCustomerAccountNo(customer.getCustomerAccountNo());
		w.setWalletBalance(0d);
		wallets.put(customer.getCustomerAccountNo(), w);
		History h=new History();
		h.setCustomerAccountNo(customer.getCustomerAccountNo());
		h.setCustomerBalance(customer.getCustomerBalance());
		h.setDepositDate(LocalDateTime.now());
		h.setDescription("Account Created");
		history.add(h);
	}

	@Override
	public void depositMoney(int cid, Double amount) 
	{
		Customer c = customers.get(cid);
		c.setCustomerBalance(c.getCustomerBalance()+amount);
		History h=new History();
		h.setCustomerAccountNo(c.getCustomerAccountNo());
		h.setCustomerBalance(c.getCustomerBalance());
		h.setDepositDate(LocalDateTime.now());
		h.setDescription("Deposited");
		history.add(h);
	}

	@Override
	public double showBalance(int cust) 
	{
		Customer c = customers.get(cust);
return 		c.getCustomerBalance();
		}

	@Override
	public double withdrawMoney(int cid, double amount) {
		
		Customer c = customers.get(cid);
		c.setCustomerBalance(c.getCustomerBalance()-amount);
	
		History h=new History();
		h.setCustomerAccountNo(c.getCustomerAccountNo());
		h.setCustomerBalance(c.getCustomerBalance());
		h.setDepositDate(LocalDateTime.now());
		h.setDescription("Withdrawn");
		history.add(h);
		return c.getCustomerBalance();
	}

	@Override
	public void bankToWallet(int accountId, int amount1) 
	{
		Customer c = customers.get(accountId);
		Wallet w = wallets.get(accountId);
		double balance=c.getCustomerBalance();
		double walletBalance = w.getWalletBalance();
		if(amount1<=balance)
		{c.setCustomerBalance(balance-amount1);
		w.setWalletBalance(walletBalance+amount1);
		History h=new History();
		h.setCustomerAccountNo(c.getCustomerAccountNo());
		h.setCustomerBalance(c.getCustomerBalance());
		h.setDepositDate(LocalDateTime.now());
		h.setDescription("Added to wallet");
		history.add(h);
		}
		else {
			System.out.println("You don't have enough balance");
		}
		
		
	}

	@Override
	public void walletToBank(int accountId, int amount1)
	{
		Customer c = customers.get(accountId);
		Wallet w = wallets.get(accountId);
		double balance=c.getCustomerBalance();
		double walletBalance = w.getWalletBalance();
		if(walletBalance>=amount1)
		{
			c.setCustomerBalance(balance+amount1);
			w.setWalletBalance(walletBalance-amount1);
			History h=new History();
			h.setCustomerAccountNo(c.getCustomerAccountNo());
			h.setCustomerBalance(c.getCustomerBalance());
			h.setDepositDate(LocalDateTime.now());
			h.setDescription("Added to bank");
			history.add(h);
		}
		else {
			System.out.println("You don't have enough balance");
		}
	}

	@Override
	public void walletToWallet(int accountId, int receiverId, int amount1)
	{
		Customer c=customers.get(accountId);
		Wallet w = wallets.get(accountId);
		Wallet w1 = wallets.get(receiverId);
		double wBalance = w.getWalletBalance();
		double w1Balance = w1.getWalletBalance();
		if (wBalance>=amount1) {
			w.setWalletBalance(wBalance-amount1);
			w1.setWalletBalance(w1Balance+amount1);
			History h=new History();
			h.setCustomerAccountNo(c.getCustomerAccountNo());
			h.setCustomerBalance(c.getCustomerBalance());
			h.setDepositDate(LocalDateTime.now());
			h.setDescription("wallet to wallet transfer");
			history.add(h);
		} else {
			System.out.println("You don't have enough balance to transfer");
		}
	}

	@Override
	public double showWalletBalance(int cust) {

		Wallet w = wallets.get(cust);
		return w.getWalletBalance();
	}

	@Override
	public List getHistory(int accountId) {
		
		List<History> hlist=new ArrayList<History>();
		for(History h:history) {
			if(h.getCustomerAccountNo()==accountId) {
				hlist.add(h);
			}
		}
		
		return hlist;
	}
	
	
	
	
}
