package AccountDao;

import java.util.HashMap;
import java.util.Map;

import AccountBean.Account;

public interface AccountDaoInterface 
{
	public Map<Double, Account> displayAccountDetails();
	public void addNewAccount(Account account);
}