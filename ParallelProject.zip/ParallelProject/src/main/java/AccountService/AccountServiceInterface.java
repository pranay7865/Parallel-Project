package AccountService;

import java.util.HashMap;
import java.util.Map;

import AccountBean.Account;


public interface AccountServiceInterface 
{
	Map<Double,Account>displayAccountDetails();
	
	public void addNewAccount(Account account) ;
}
