package AccountService;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import AccountMain.Main;
import AccountBean.Account;
import AccountBean.History;
import AccountDao.AccountDao;

public class AccountService implements AccountServiceInterface 
{
	AccountDao dao=new AccountDao();
	LocalDateTime n=LocalDateTime.now();
	Map<Double,Account>account=new HashMap<Double,Account>();
	Map<LocalDateTime,History>history1=new HashMap<LocalDateTime,History>();
	
	public Map<Double, Account> displayAccountDetails() 
	{
		account=dao.displayAccountDetails();
		return account;
	}
	public void addNewAccount(Account account) 
	{
		dao.addNewAccount(account);
	}
	public int deposit(int account_number,int amount) 
	{
		int amountAfterDeposit=dao.deposit(account_number,amount);
		return amountAfterDeposit;
	}
	public int withdraw(int account_Number_check1, int amountWithdrawal) 
	{
		int amountAfterWithdrawal=dao.withdraw(account_Number_check1,amountWithdrawal);
		return amountAfterWithdrawal;
	}
	public int getCurrentBalance(int account_Number_Check) 
	{
		return dao.getCurrentBalance(account_Number_Check);
	}
	public String fundTransfer(int account_number, int reciever_account_number,int amount) 
	{
		String str1=dao.fundTransfer(account_number,reciever_account_number,amount);
		return str1;
	}
	
}
